package day5.enumEx.실습하기;

public enum DAY2 {
	
	    SUNDAY,
	    MONDAY,
	    TUESDAY,
	    WEDNESDAY,
	    THURSDAY,
	    FRIDAY,
	    SATURDAY

}
