package day5.enumEx.실습하기;


//요일정보를 상수로 저장
//상수는 대문자
//final   => 변수를 상수화 하는 키워드 
// 상수 는 값을 이용할 때만 사용가능 

public class DAY {

	static   final int    SUNDAY =0;
	static   final int    MONDAY =1;
	static   final  int   TUESDAY=2;
	static   final  int   WEDNESDAY =3;
	static   final  int   THURSDAY=4;
	static   final  int    FRIDAY=5;
	static    final  int   SATURDAY=6;

}
