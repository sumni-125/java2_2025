package day5.enumEx.실습하기;

public class Ex01 {

	public static void main(String[] args) {
		 
		
		
		

	}

}
