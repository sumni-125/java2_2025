package day5.di_injection.service;

public interface MyDAOInterface {
	
	public void  selectAll();
	public void  selelctOne();
	public  void insert();
	public  void delete();
	public void update();
	

}
