package day5.di_injection;

public interface Bettery {
	
	int  getEnergy ();

}
