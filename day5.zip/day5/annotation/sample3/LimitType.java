package day5.annotation.sample3;


public enum LimitType {
	MAX , MIN
}
