package day2.lambda.무빙;

public class Moving {

	String name;
	String alias;
	int power;
	
	public Moving() {
		// TODO Auto-generated constructor stub
	}

	public Moving(String name, String alias, int power) {
		super();
		this.name = name;
		this.alias = alias;
		this.power = power;
	}

	@Override
	public String toString() {
		return "Moving [name=" + name + ", alias=" + alias + ", power=" + power + "]";
	}
	
	
	
	
}
